"""
    Este programa escreve ‘Hello, World!’ na saída padrão
    Este é um comentário de múltiplas linhas 
"""
print('Hello, World!')   # Escreve na tela (Comentário de uma só linha)