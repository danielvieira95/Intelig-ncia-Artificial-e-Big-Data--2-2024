#!/usr/bin/env python3
# -*- coding: utf-8 -*-
eh_impar = (57%2 == 0)
print(eh_impar)
""" O valor contido em eh_impar é um booleano, pois a variável foi inicializada
    com o resultado de uma operação de comparação. """