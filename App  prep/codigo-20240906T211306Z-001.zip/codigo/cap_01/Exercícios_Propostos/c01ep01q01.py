#!/usr/bin/env python3
# -*- coding: utf-8 -*-
nome = 'Francisco'
idade = 43
print(f'Nome: {nome}, Idade: {idade}')
print('\'s, \"x\", \\\\')
pi = 3.1415926
print(f'Pi = {pi:.2f}')
print((5*7)-((6*4)+(20/2)))
