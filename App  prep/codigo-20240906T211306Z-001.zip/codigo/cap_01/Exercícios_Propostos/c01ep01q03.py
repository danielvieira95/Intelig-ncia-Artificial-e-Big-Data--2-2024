#!/usr/bin/env python3
# -*- coding: utf-8 -*-
a = 1
b = -7
c = 12
delta = (b**2 - 4 * a * c)
print(f'O discriminante (delta) de a={a}, b={b} e c={c} é {delta}.')
