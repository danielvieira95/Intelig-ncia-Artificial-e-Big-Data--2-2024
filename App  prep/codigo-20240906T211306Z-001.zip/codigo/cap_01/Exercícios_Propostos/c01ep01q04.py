#!/usr/bin/env python3
# -*- coding: utf-8 -*-
a = 1
b = -7
c = 12
def delta():
    resultado = (b**2 - 4 * a * c)
    return resultado

print(f'O discriminante (delta) de a={a}, b={b} e c={c} é {delta()}.')
