print(5 != 3)               # resultado: True
print(10 != 10)             # resultado: False
print("maçã" != "maçã")     # resultado: False
print("maçã" != "Maçã")     # resultado: True
print(2 + 2 != 4)           # resultado: False
print(10 != 10.0)           # resultado: False    