#!/usr/bin/env python3
# -*- coding: utf-8 -*-
x = 1	          # x contém um inteiro
print(type(x))
x = 'abc'      # Agora, x contém uma string
print(type(x))
x = True       # E agora, um booleano
print(type(x))
