#!/usr/bin/env python3
# -*- coding: utf-8 -*-
soma = 0
for i in range(1,101):
    soma = soma + i
print(f'A soma dos números de 1 a 100 é {soma}.')
