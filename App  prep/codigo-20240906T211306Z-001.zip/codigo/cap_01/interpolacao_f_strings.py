#!/usr/bin/env python3
# -*- coding: utf-8 -*-
codigo = 27
pi = 3.1415926
print(f'Código do usuário: {codigo}')
print(f'15 em octal é {15:o}')
print(f'100 em hexadecimal é {100:x}')
print(f'pi com duas casas decimais é aproximadamente {pi:.2f}')
print(f'pi com três casas decimais é aproximadamente {pi:.3f}')
nome = 'Fulano'
print(f'Meu nome é {nome}')