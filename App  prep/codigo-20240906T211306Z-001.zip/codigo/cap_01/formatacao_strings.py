#!/usr/bin/env python3
# -*- coding: utf-8 -*-
print('Código do usuário: %d' % 27)
print('15 em octal é %o' % 15)
print('100 em hexadecimal é %x' % 100)
print('pi com duas casas decimais é aproximadamente %.2f' % 3.1415926)
print('pi com três casas decimais é aproximadamente %.3f' % 3.1415926)
nome = 'Fulano'
print('Meu nome é %s' % nome)