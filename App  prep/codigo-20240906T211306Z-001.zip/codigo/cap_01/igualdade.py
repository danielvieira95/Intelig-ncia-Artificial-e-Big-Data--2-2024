#!/usr/bin/env python3
# -*- coding: utf-8 -*-
print(5 == 3)               # resultado: False
print(10 == 10)             # resultado: True
print("maçã" == "maçã")     # resultado: True
print("maçã" == "Maçã")     # resultado: False
print(2 + 2 == 4)           # resultado: True
print(10 == 10.0)           # resultado: True