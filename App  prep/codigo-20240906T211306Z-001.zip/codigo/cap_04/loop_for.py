cidades = ['Alian�a','Belo Jardim','Caruaru','Petrolina']
for cidade_atual in cidades:
    print('A cidade atualmente examinada � %s' % cidade_atual)
