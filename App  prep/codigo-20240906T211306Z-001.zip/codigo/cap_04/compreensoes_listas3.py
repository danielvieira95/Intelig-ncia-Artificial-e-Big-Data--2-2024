numeros = [(p1, p2)
           for p1 in range(7)
           for p2 in range(7)]
print(f'Pares criados: {numeros}', sep=' ')