print('C3 = {x | -20<=x<=40 e x é ímpar}')
c3 = [x * 2 + 1 for x in range(-10, 20)]
print(c3, sep=' ')
