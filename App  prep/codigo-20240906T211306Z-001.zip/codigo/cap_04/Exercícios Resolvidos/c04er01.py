for x in range(5000,10001):
    if (x % 3 == 0) and (x % 7 == 0):
        print(f'{x} é divisível, simultaneamente, por 3 e 7')
