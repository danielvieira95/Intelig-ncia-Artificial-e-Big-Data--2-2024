n = 20
contador = 0
x1 = 1
x2 = 1
resultado = 1
while(contador < n):
    contador = contador + 1
    resultado = resultado * contador
print(f'produtório = {resultado}')