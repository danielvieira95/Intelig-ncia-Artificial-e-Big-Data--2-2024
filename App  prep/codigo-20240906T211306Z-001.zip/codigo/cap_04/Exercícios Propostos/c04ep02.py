#!/usr/bin/env python3
# -*- coding: utf-8 -*-
lista = [x * 2 for x in range(0, 51)]
for x in lista:
    print(x * 1.5)
