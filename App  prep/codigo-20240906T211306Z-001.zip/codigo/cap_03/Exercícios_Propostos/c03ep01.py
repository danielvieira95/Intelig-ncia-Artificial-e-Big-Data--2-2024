var1 = 15
var2 = 30
var3 = 22
if (var1 > var2) and (var1 < var3):
    print(f'A mediana é {var1} e está armazenada em var1')
elif (var2 > var1) and (var2 < var3):
    print(f'A mediana é {var2} e está armazenada em var2')
elif (var3 > var1) and (var3 < var2):
    print(f'A mediana é {var3} e está armazenada em var3')
