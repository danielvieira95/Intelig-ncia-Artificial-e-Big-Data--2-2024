x = 5
if x > 0:
    print(f'{x} é um número positivo.')
print("Esta linha será impressa todas as vezes.")

x = -1
if x > 0:
    print(f'{x} é um número positivo.')
print("Esta linha também será impressa sempre.")
