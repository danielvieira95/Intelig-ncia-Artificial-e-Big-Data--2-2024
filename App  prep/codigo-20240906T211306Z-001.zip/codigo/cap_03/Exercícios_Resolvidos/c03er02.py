lado1 = 3
lado2 = 8
lado3 = 10
resultado = False
if (lado2 + lado3> lado1) and (lado1 + lado3 > lado2) and (lado1 + lado2 > lado3):
    print('Os valores fornecidos FORMAM um triângulo.')
else:
    print('Os valores fornecidos NÃO FORMAM um triângulo.')
