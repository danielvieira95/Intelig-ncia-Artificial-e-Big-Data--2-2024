var1 = 13
var2 = 27
var3 = 8
if (var1 > var2) and (var1 > var3):
    print(f'O maior valor é {var1} e está armazenado em var1')
elif (var2 > var1) and (var2 > var3):
    print(f'O maior valor é {var2} e está armazenado em var2')
elif (var3 > var1) and (var3 > var2):
    print(f'O maior valor é {var3} e está armazenado em var3')
