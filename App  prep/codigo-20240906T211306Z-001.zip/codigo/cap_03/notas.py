media = 8.5
if media >= 7.0:
    print('Parabéns! Você foi aprovado por média.')
elif (media < 7.0) and (media >=3.0):
    print('Você fará prova final.')
else:
    print('Você foi reprovado.')
