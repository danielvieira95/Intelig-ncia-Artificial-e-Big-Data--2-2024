produto = {
        'codigo': '00012-X',
        'nome': 'Alicate de corte tam. 9',
        'preco': 50.27}
print(f'Chaves do produto: {produto.keys()}')
print(f'Valores do produto: {produto.values()}')
print(f'Tuplas (chave, valor) do produto: {produto.items()}')
