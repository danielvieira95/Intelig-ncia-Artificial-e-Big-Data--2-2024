#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 19:31:40 2019

@author: francisco
"""

lista_carros = ['Gol', 'Uno', 'HB20', 'Ka']     # Criando uma lista
print(f'Conteúdo da lista: {lista_carros}')         # Imprimindo toda a lista
print(f'O primeiro elemento da lista é {lista_carros[0]}')
print(f'O quarto elemento da lista é {lista_carros[3]}')
print(f'O quinto elemento da lista é {lista_carros[4]}')