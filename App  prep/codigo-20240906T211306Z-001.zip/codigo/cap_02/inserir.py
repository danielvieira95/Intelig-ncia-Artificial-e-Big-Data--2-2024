# Primeiro, crio uma lista com algumas ferramentas:
ferramentas = ['Alicate de Pressão','Chave Philips','Formão']
print('Lista inicial de ferramentas: ', ferramentas)
# Agora, adiciono mais duas, de forma a manter a ordem alfabética:
ferramentas.insert(2, 'Chave Torx')
print('Comprei uma chave torx: ', ferramentas)
ferramentas.insert(0, 'Alicate de corte')
print('Comprei um alicate de corte: ', ferramentas)