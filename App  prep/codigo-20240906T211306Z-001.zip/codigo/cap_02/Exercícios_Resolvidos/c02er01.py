#!/usr/bin/env python3
# -*- coding: utf-8 -*-
valores = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Lembre-se que as listas são baseadas em zero
print(f'O s�timo elemento da lista � {valores[6]}.')
print(f'E o conte�do da lista completa: {valores}.')