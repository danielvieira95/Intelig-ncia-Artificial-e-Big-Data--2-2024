#!/usr/bin/env python3
# -*- coding: utf-8 -*-
A = {1, 2, 3, 4, 5}
B = {0, 2, 4, 6, 8, 10}
print(f'A união B = {A|B}')
print(f'A interseção B = {A&B}')
