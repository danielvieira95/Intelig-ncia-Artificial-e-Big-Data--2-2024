#!/usr/bin/env python3
# -*- coding: utf-8 -*-
valores = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
numeros_extenso = ['um','dois', 'tr�s', 'quatro', 'cinco', 'seis', 'sete', 
                   'oito', 'nove', 'dez']
lista_numeros = [valores, numeros_extenso]
print(f'Conte�do da lista: {lista_numeros}.')
print(f'Primeiro elemento da lista: {lista_numeros[0][0]} - {lista_numeros[1][0]}.')
print(f'�ltimo elemento da lista: {lista_numeros[0][9]} - {lista_numeros[1][9]}.')
