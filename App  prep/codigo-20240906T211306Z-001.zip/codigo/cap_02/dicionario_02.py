produto = {
        'codigo': '00035-B',
        'nome': 'Chave de Fenda n. 15',
        'preco': 29.759}
print(f'Cadastrado o produto: {produto}')
print(f'Código do produto: {produto["codigo"]}')
print(f'Nome do produto: {produto["nome"]}')
print(f'Preço do produto: R$ {produto["preco"]:.2f}')