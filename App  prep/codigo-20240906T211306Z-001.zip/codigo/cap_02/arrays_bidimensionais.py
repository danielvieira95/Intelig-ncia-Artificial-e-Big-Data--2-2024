#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 20:05:14 2019

@author: francisco
"""

carros_populares = ['Gol', 'Uno', 'HB20', 'Ka']
superesportivos = ['Ferrari', 'Lamborguini', 'Porsche']
lista_carros = [carros_populares, superesportivos]
print(f'Carros populares: {lista_carros[0]}')
print(f'Superesportivos: {lista_carros[1]}')
print(f'Primeiro carro popular: {lista_carros[0][0]}')
print(f'Primeiro superesportivo: {lista_carros[1][0]}')