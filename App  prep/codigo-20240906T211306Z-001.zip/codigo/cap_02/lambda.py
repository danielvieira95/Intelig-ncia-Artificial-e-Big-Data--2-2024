delta = lambda a, b, c: b**2 - 4 * a * c
print(f'Usando uma expressão lambda para calcular delta(1, 12, -13): {delta(1, 12, -13)}')