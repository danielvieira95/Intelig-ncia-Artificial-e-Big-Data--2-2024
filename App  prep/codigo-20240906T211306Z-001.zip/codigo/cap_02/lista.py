#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 18:01:15 2019

@author: amilcar, francisco
"""
lista_produtos = []
print(f'Criando uma lista de produtos vazia: {lista_produtos}')
print('Adicionando caneta esferográfica preta à lista:')
lista_produtos.append('caneta esferográfica preta')
print(lista_produtos)
print('Adicionando caneta esferográfica azul à lista:')
lista_produtos.append('caneta esferográfica azul')
print(lista_produtos)
print('Adicionando resma de papel sulfite à lista:')
lista_produtos.append('resma de papel sulfite')
print(lista_produtos)
