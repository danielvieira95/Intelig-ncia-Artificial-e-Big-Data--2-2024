clientes = {}
funcionarios = dict()
pesos = { 'Fulano': 80.2, 'Cicrano': 57.5}
