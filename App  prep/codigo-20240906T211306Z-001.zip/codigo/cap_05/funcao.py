def delta(a, b, c):
    resultado = b**2 - 4 * a * c
    return resultado
