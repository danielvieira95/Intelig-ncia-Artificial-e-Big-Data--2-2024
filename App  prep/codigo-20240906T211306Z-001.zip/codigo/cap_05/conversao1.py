a = '123'
a_inteiro = int(a)
print(f'Convertendo a para inteiro: {a_inteiro}')

e = 2.718281
parte_inteira_de_e = int(e)
print(f'e (base dos logaritmos neperianos) vale, aproximadamente: {e}')
print(f'A parte inteira de e vale: {parte_inteira_de_e}')

print(f'Convertendo True para int, obtem-se: {int(True)}')
print(f'Convertendo False para int, obtem-se: {int(False)}')
