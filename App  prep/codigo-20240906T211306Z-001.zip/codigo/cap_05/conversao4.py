codigo = 300
nome = 'Fulano'
mensagem = 'O aluno de código ' + codigo + ' é ' + nome
