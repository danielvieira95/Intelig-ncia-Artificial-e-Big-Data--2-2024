numero_inteiro = 123
numero_real = 456.78
print(f'Convertendo o inteiro {numero_inteiro} para complexo, obtém-se: {complex(numero_inteiro)}')
print(f'Convertendo o inteiro {numero_real} para complexo, obtém-se: {complex(numero_real)}')
