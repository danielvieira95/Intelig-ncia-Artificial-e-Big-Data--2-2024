dados_lista = ['A', 'B', 'C']
dados_tupla = (1, 2, 3, 4)
dados_string = 'PALAVRA'
conjunto_1 = set(dados_lista)
conjunto_2 = set(dados_tupla)
conjunto_3 = set(dados_string)
print(f'Convertendo-se {dados_lista} em conjunto, obtém-se {conjunto_1}.')
print(f'Convertendo-se {dados_tupla} em conjunto, obtém-se {conjunto_2}.')
print(f'Convertendo-se {dados_string} em conjunto, obtém-se {conjunto_3}.')
