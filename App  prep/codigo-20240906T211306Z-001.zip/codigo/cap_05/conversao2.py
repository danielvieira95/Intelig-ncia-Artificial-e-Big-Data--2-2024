x = 1000
y = float(x)
print(y)
print(f'x * y = {x * y}')

