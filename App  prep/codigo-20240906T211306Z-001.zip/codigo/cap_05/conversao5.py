codigo = 300
nome = 'Fulano'
mensagem = 'O aluno de código ' + str(codigo) + ' é ' + nome
