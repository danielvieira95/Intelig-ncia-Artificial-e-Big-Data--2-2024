#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math

def distancia(x1, y1, x2, y2):
    resultado = math.sqrt(((x2-x1)**2) + ((y2-y1)**2))
    return resultado
